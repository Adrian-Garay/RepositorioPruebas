#ifndef LISTA_H
#define LISTA_H
#include <string>

class Listas
{
    public:
        Listas();
        virtual ~Listas();

    protected:

    private:
};

#endif // LISTAS_H
