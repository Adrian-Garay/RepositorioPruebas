#include "Lista.h"
#include <string>

Listas::Listas()
{
    //ctor
}

Listas::~Listas()
{
    //dtor
}
